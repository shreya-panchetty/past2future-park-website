var Getday = new Date().getDay();
let display = document.getElementById("openingHours");
let display2 = document.getElementById("openingHours2");

switch (new Date().getDay()) {
    case 0:
        day = "Sunday";
        display.innerHTML = "9am - 10:30pm";
        display2.innerHTML = "9am - 10:30pm";
        break;
    case 1:
        day = "Monday";
        display.innerHTML = "10am - 9:30pm";
        display2.innerHTML = "10am - 9:30pm";
        break;
    case 2:
        day = "Tuesday";
        display.innerHTML = "10am - 9:30pm";
        display2.innerHTML = "10am - 9:30pm";
        break;
    case 3:
        day = "Wednesday";
        display.innerHTML = "10am - 9:30pm";
        display2.innerHTML = "10am - 9:30pm";
        break;
    case 4:
        day = "Thursday";
        display.innerHTML = "10am - 9:30pm";
        display2.innerHTML = "10am - 9:30pm";
        break;
    case 5:
        day = "Friday";
        display.innerHTML = "10am - 9:30pm";
        display2.innerHTML = "10am - 10:30pm";
        break;
    case 6:
        day = "Saturday";
        display.innerHTML = "10am - 10:30pm";
        display2.innerHTML = "10am - 10:30pm";
        break;
}